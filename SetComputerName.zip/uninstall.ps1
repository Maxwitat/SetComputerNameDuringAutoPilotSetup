$registryPath = "HKLM:\SOFTWARE\Setup"
$valueName = "RenameComputer"

# Check if the registry value exists
if (Test-Path -Path "$registryPath\$valueName") {
    # Registry value exists, so delete it
    Remove-ItemProperty -Path $registryPath -Name $valueName
} 